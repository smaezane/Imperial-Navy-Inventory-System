/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.InhousePart;
import Model.Inventory;
import Model.Part;
import Model.outsourcedPart;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sofrona
 */
public class ModifyPartController implements Initializable {

    @FXML
    private RadioButton inhouseRadio;
    @FXML
    private RadioButton outsourcedRadio;
    @FXML
    private TextField partIDText;
    @FXML
    private TextField partNameText;
    @FXML
    private TextField partStockText;
    @FXML
    private TextField partPriceText;
    @FXML
    private TextField partMinText;
    @FXML
    private TextField partMaxText;
    @FXML
    private Button saveModifyPartButton;
    @FXML
    private Button cancelModifyPartButton;
    @FXML
    private Label changingLabel;
    @FXML
    private TextField changingLabelText;
    @FXML
    private ToggleGroup Part;
    InhousePart part1;
    outsourcedPart part2;
    Part part3;
       
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void outsourcedRadioHandler(ActionEvent event) throws IOException {
        changingLabel.setText("Company Name");
        changingLabelText.setPromptText("Company Name");
    }

    @FXML
    private void cancelModifyPartHandler(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Your actions have not been saved. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {

            Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);

            //This line gets the Stage information
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(tableViewScene);
            window.show();
        }

    }

    @FXML
    private void saveModifyPartHandler(ActionEvent event) throws IOException {
try {
        int partID = Integer.parseInt(partIDText.getText());
        String partName = partNameText.getText();
        Double partPrice = Double.parseDouble(partPriceText.getText());
        int inStock = Integer.parseInt(partStockText.getText());
        int partMin = Integer.parseInt(partMinText.getText());
        int partMax = Integer.parseInt(partMaxText.getText());
        String companyName = changingLabelText.getText();
         boolean addFail = true;
             
            
             if (partMax == partMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Part Max cannot equal Part Min");
            alert.showAndWait();
            addFail = true;
             }
            
            
            if (inStock > partMax){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot exceed Part Maximum");
            alert.showAndWait();
            addFail = true;
             }
            
            if (inStock < partMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot be less than Part Minimum");
            alert.showAndWait();
            addFail = true;
             }
            
            if (addFail == false){

        Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        //This line gets the Stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
            }
}
    
    
catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Please enter a valid value for each text field");
            alert.showAndWait();
        }
    }

    @FXML
    private void inhouseRadioHandler(ActionEvent event) {
        changingLabel.setText("Machine ID");
        changingLabelText.setPromptText("Machine ID");

    }

    void setPart(Part part, String modify) {
        
       this.part3 = part;
       
       
   partIDText.setText(Integer.toString(part.getPartID()));
   partNameText.setText(part.getPartName());
   partStockText.setText(Integer.toString(part.getPartStock()));
   partPriceText.setText(Double.toString(part.getPartPrice()));
   partMinText.setText(Integer.toString(part.getPartMin()));
   partMaxText.setText(Integer.toString(part.getPartMax()));
   
   
    }
    
    void setOutsourcedPart(outsourcedPart part, String modify) {
        
       this.part2 = part;
       
       
   partIDText.setText(Integer.toString(part.getPartID()));
   partNameText.setText(part.getPartName());
   partStockText.setText(Integer.toString(part.getPartStock()));
   partPriceText.setText(Double.toString(part.getPartPrice()));
   partMinText.setText(Integer.toString(part.getPartMin()));
   partMaxText.setText(Integer.toString(part.getPartMax()));
   changingLabelText.setText(part.getCompanyName());
   
   
    }
    
    void setInhousePart(InhousePart part, String modify) {
        
       this.part1 = part;
       
       
   partIDText.setText(Integer.toString(part.getPartID()));
   partNameText.setText(part.getPartName());
   partStockText.setText(Integer.toString(part.getPartStock()));
   partPriceText.setText(Double.toString(part.getPartPrice()));
   partMinText.setText(Integer.toString(part.getPartMin()));
   partMaxText.setText(Integer.toString(part.getPartMax()));
   changingLabelText.setText(Integer.toString(part.getMachineID()));
   
   
    }
}
