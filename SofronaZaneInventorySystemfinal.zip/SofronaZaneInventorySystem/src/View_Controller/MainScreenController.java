/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.InhousePart;
import java.util.EventListener;
import Model.Inventory;
import static Model.Inventory.getlistParts;
import static Model.Inventory.listParts;
import static Model.Inventory.listProducts;
import Model.Part;
import Model.Product;
import Model.outsourcedPart;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Sofrona
 */
public class MainScreenController implements Initializable {

    @FXML
    private AnchorPane mainPartsTable;

    @FXML
    private TableColumn<Part, Integer> partsIDCollumn;

    @FXML
    private TableColumn<Part, String> partsNameCollumn;

    @FXML
    private TableColumn<Part, Integer> partsInventoryCollumn;

    @FXML
    private TableColumn<Part, Double> partsPriceCollumn;

    @FXML
    private Button deletePartsButton;

    @FXML
    private Button modifyPartsButton;

    @FXML
    private Button addPartsButton;

    @FXML
    private Button searchPartsButton;

    @FXML
    private TextField partsSearchText;

    @FXML
    private TableColumn<Product, Integer> productsIDCollumn;

    @FXML
    private TableColumn<Product, String> productsNameCollumn;

    @FXML
    private TableColumn<Product, Integer> productsInventoryCollumn;

    @FXML
    private TableColumn<Product, Double> productsPriceCollumn;

    @FXML
    private Button deleteProductsButton;

    @FXML
    private Button modifyProductsButton;

    @FXML
    private Button addProductsButton;

    @FXML
    private Button searchProductsButton;

    @FXML
    private TextField productsSearchText;

    @FXML
    private Button sysExitButton;

    @FXML
    private TableView<Part> partsTableView;

    @FXML
    private TableView<Product> productsTableView;

    @FXML
    void addPartsHandler(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("AddPart.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        //This line gets the Stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    public void addProductsHandler(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("AddProduct.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        //This line gets the Stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    void deletePartsHandler(ActionEvent event) {
        {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This action is permanent. Do you want to continue?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK);
            Part part = partsTableView.getSelectionModel().getSelectedItem();
            if (part != null) {
                partsTableView.getSelectionModel().clearSelection();
            }
            listParts.remove(part);

        }
    }

    @FXML
    void deleteProductsHandler(ActionEvent event) {
        {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This action is permanent. Do you want to continue?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK);
                    
            Product product = productsTableView.getSelectionModel().getSelectedItem();
            boolean deleteFail = false;
            
            if (product.associatedParts.size() > 1);{
            Alert alert1 = new Alert(Alert.AlertType.ERROR);
            alert1.setTitle("Error Dialogue");
            alert1.setContentText("Cannot delete a product with associated parts");
            alert1.showAndWait();
            }   deleteFail = true;
            
        
            if (deleteFail = false)  {         
            if (product.associatedParts.isEmpty()) {
                productsTableView.getSelectionModel().clearSelection();
                listProducts.remove(product);
            }

            }

        }
    }

    @FXML
    void modifyPartsHandler(ActionEvent event) throws IOException {
        try {
            Stage stage;
            Parent root;
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View_Controller/ModifyPart.fxml"));
            loader.load();
            ModifyPartController controller = loader.getController();
            
            Part part = partsTableView.getSelectionModel().getSelectedItem();
            if (part instanceof outsourcedPart){
                outsourcedPart castPart = (outsourcedPart) part;
                controller.setOutsourcedPart(castPart, "Modify");
            }
            
             if (part instanceof InhousePart){
                InhousePart castPart = (InhousePart) part;
                controller.setInhousePart(castPart, "Modify");
            }
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.getRoot());
            stage.setScene(scene);
            stage.show();

        } catch (NullPointerException n) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select an item to modify");
            Optional<ButtonType> result = alert.showAndWait();
        }
    }

    @FXML
    void modifyProductsHandler(ActionEvent event) throws IOException {
        try {
            Stage stage;
            Parent root;
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View_Controller/ModifyProduct.fxml"));
            loader.load();
            ModifyProductController controller = loader.getController();
            Product product = productsTableView.getSelectionModel().getSelectedItem();
            controller.setProduct(product, "Modify");
            controller.setTableView2(product.getAssociatedParts(), "Modify");
            
            //load assicatedParts list into the table
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.getRoot());
            stage.setScene(scene);
            stage.show();

        } catch (NullPointerException n) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select an item to modify");
            Optional<ButtonType> result = alert.showAndWait();
        }
    }

    @FXML
    void searchPartsHandler(ActionEvent event) {
        String partsLookName = partsSearchText.getText();

        partsTableView.setItems(filterPart(partsLookName));

    }

    @FXML
    void searchProductsHandler(ActionEvent event) {
        String productLookName = productsSearchText.getText();

        productsTableView.setItems(filterProduct(productLookName));
    }

    
    public Part selectPart(int id) {
        for (Part part : Inventory.getlistParts()) {
            if (part.getPartID() == id) {
                return part;
            }
        }
        return null;
    }
    
    public Product selectProduct(int id) {
        for (Product product : Inventory.getlistProducts()) {
            if (product.getProductID() == id) {
                return product;
            }
        }
        return null;
    }

    public ObservableList<Product> filterProduct(String searchInput) {
        if (!(Inventory.getselectedProducts().isEmpty())) {
            Inventory.getselectedProducts().clear();
        }

        if (Inventory.getselectedProducts().isEmpty()) {
            Inventory.getselectedProducts();

        }
        try {
            // checking valid integer using parseInt() method 
            Integer.parseInt(searchInput);
            for (Product product : Inventory.getlistProducts()) {
                if (product.getProductID() == Integer.parseInt(searchInput)) {
                    Inventory.getselectedProducts().add(product);

                }
            }
        } 
        catch (NumberFormatException e) {
            String lowerCaseFilter = searchInput.toLowerCase();

            for (Product product : Inventory.getlistProducts()) {
                if (product.getProductName().contains(lowerCaseFilter)) {
                    Inventory.getselectedProducts().add(product);
                }
            }
        }
        return Inventory.getselectedProducts();
    }

    public ObservableList<Part> filterPart(String searchInput) {
        if (!(Inventory.getselectedParts().isEmpty())) {
            Inventory.getselectedParts().clear();
        }

        if (Inventory.getselectedParts().isEmpty()) {
            Inventory.getselectedParts();

        }
        try {
            // checking valid integer using parseInt() method 
            Integer.parseInt(searchInput);
            for (Part part : Inventory.getlistParts()) {
                if (part.getPartID() == Integer.parseInt(searchInput)) {
                    Inventory.getselectedParts().add(part);

                }
            }
        } catch (NumberFormatException e) {
            String lowerCaseFilter = searchInput.toLowerCase();

            for (Part part : Inventory.getlistParts()) {
                if (part.getPartName().toLowerCase().contains(lowerCaseFilter)) {
                    Inventory.getselectedParts().add(part);
                }
            }
        }
        return Inventory.getselectedParts();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        partsTableView.setItems(Inventory.getlistParts());

        partsIDCollumn.setCellValueFactory(new PropertyValueFactory<>("partID"));
        partsNameCollumn.setCellValueFactory(new PropertyValueFactory<>("partName"));
        partsPriceCollumn.setCellValueFactory(new PropertyValueFactory<>("partPrice"));
        partsInventoryCollumn.setCellValueFactory(new PropertyValueFactory<>("partStock"));

        productsTableView.setItems(Inventory.getlistProducts());

        productsIDCollumn.setCellValueFactory(new PropertyValueFactory<>("productID"));
        productsNameCollumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productsPriceCollumn.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
        productsInventoryCollumn.setCellValueFactory(new PropertyValueFactory<>("inStock"));

    }

    @FXML
    private void sysExitHandler(ActionEvent event) {
        Stage stage = (Stage) sysExitButton.getScene().getWindow();
        stage.close();
    }
}
