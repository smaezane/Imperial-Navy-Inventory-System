/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.InhousePart;
import Model.Inventory;
import Model.Part;
import Model.Product;
import Model.outsourcedPart;
import java.lang.String;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sofrona
 */
public class AddPartController implements Initializable {

    @FXML
    private RadioButton outsourcedRadio;
    @FXML
    private TextField partIDText;
    @FXML
    private TextField partNameText;
    @FXML
    private TextField partStockText;
    @FXML
    private TextField partPriceText;
    @FXML
    private TextField partMinText;
    @FXML
    private TextField partMaxText;
    private TextField machineIDText;
    @FXML
    private Button saveAddPartButton;
    @FXML
    private Button cancelAddPartButton;
    @FXML
    private Label changingLabel;
    @FXML
    private RadioButton inhouseRadio;
    @FXML
    private TextField changingLabelText;
    @FXML
    private ToggleGroup Part;
    private Product draftProduct;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }

    @FXML
    private void outsourcedHandler(ActionEvent event) {
        changingLabel.setText("Company Name");
        changingLabelText.setPromptText("Company Name");

    }

    @FXML
    private void saveAddPartHandler(ActionEvent event) throws IOException {
try {
        String partName = partNameText.getText();
        Double partPrice = Double.parseDouble(partPriceText.getText());
        int inStock = Integer.parseInt(partStockText.getText());
        int partMin = Integer.parseInt(partMinText.getText());
        int partMax = Integer.parseInt(partMaxText.getText());
        boolean addFail = false;
        
            if (partMin > partMax){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Part Min cannot be greater than Part Max");
            alert.showAndWait();
            addFail = true;
             }
            
            if (partMax < partMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Part Max cannot be less than Part Min");
            alert.showAndWait();
            addFail = true;
             }
            
             if (partMax == partMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Part Max cannot equal Part Min");
            alert.showAndWait();
            addFail = true;
             }
            
            
            if (inStock > partMax){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot exceed Part Maximum");
            alert.showAndWait();
            addFail = true;
             }
            
            if (inStock < partMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot be less than Part Minimum");
            alert.showAndWait();
            addFail = true;
             }
            
            if (addFail == false) {
            
            if (outsourcedRadio.isSelected()) {
                String companyName = changingLabelText.getText();
                Inventory.addPart(new outsourcedPart(companyName, partName, partPrice, inStock, partMin, partMax));
            }
            
            if (inhouseRadio.isSelected()) {
                int machineID = Integer.parseInt(changingLabelText.getText());
                Inventory.addPart(new InhousePart(machineID, partName, partPrice, inStock, partMin, partMax));
            }

            
            Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);

            //This line gets the Stage information
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(tableViewScene);
            window.show();
            }
            
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Please enter a valid value for each text field");
            alert.showAndWait();
        }
    }

    @FXML
    private void cancelAddPartHandler(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Your actions have not been saved. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {

            Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);

            //This line gets the Stage information
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(tableViewScene);
            window.show();
        }

    }

    @FXML
    private void inhouseRadioHandler(ActionEvent event) {
        changingLabel.setText("Machine ID");
        changingLabelText.setPromptText("Machine ID");
    }
}
