/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.Inventory;
import static Model.Inventory.listParts;
import Model.Part;
import Model.Product;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sofrona
 */
public class ModifyProductController implements Initializable {

    @FXML
    private TextField ModifyproductIDText;
    @FXML
    private TextField ModifyproductNameText;
    @FXML
    private TextField ModifyproductStockText;
    @FXML
    private TextField ModifyproductPriceText;
    @FXML
    private TextField ModifyproductMinText;
    @FXML
    private TextField ModifyproductMaxText;
    @FXML
    private Button searchButton;
    @FXML
    private TableView<Part> partTableView1;
    @FXML
    private TableColumn<Part, Integer> partIDCollumn1;
    @FXML
    private TableColumn<Part, String> partNameCollumn1;
    @FXML
    private TableColumn<Part, Integer> partStockCollumn1;
    @FXML
    private TableColumn<Part, Double> partPriceCollumn1;
    @FXML
    private TextField searchText;
    @FXML
    private Button addButton;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;
    @FXML
    private TableColumn<Part, Integer> partIDCollumn2;
    @FXML
    private TableColumn<Part, String> partNameCollumn2;
    @FXML
    private TableColumn<Part, Integer> partStockCollumn2;
    @FXML
    private TableColumn<Part, Double> partPriceCollumn2;
    @FXML
    private Button deleteButton;

    public ObservableList<Part> tempParts = FXCollections.observableArrayList();
    @FXML
    private TableView<Part> partTableView2;
    private Product draftProduct;
    public ObservableList<Part> getTempParts() {
        return tempParts;
    }
    
public ObservableList<Part> filterPart(String searchInput) {
        if (!(Inventory.getselectedParts().isEmpty())) {
            Inventory.getselectedParts().clear();
        }
        
        if (Inventory.getselectedParts().isEmpty()){
            Inventory.getselectedParts();
        
        }
        try 
        { 
            // checking valid integer using parseInt() method 
            Integer.parseInt(searchInput); 
            for (Part part : Inventory.getlistParts()) {
            if (part.getPartID() == Integer.parseInt(searchInput)) {
                Inventory.getselectedParts().add(part);
            
        }  
            }
        }
        catch (NumberFormatException e)  
        { 
            String lowerCaseFilter = searchInput.toLowerCase();
            
            for (Part part : Inventory.getlistParts()) {
            if (part.getPartName().toLowerCase().contains(lowerCaseFilter)) {
                Inventory.getselectedParts().add(part);
        } 
            }
        }
     return Inventory.getselectedParts();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        partTableView1.setItems(Inventory.getlistParts());

        partIDCollumn1.setCellValueFactory(new PropertyValueFactory<>("partID"));
        partNameCollumn1.setCellValueFactory(new PropertyValueFactory<>("partName"));
        partPriceCollumn1.setCellValueFactory(new PropertyValueFactory<>("partPrice"));
        partStockCollumn1.setCellValueFactory(new PropertyValueFactory<>("partStock"));

        partTableView2.setItems(tempParts);
        partIDCollumn2.setCellValueFactory(new PropertyValueFactory<>("partID"));
        partNameCollumn2.setCellValueFactory(new PropertyValueFactory<>("partName"));
        partPriceCollumn2.setCellValueFactory(new PropertyValueFactory<>("partPrice"));
        partStockCollumn2.setCellValueFactory(new PropertyValueFactory<>("partStock"));

        
    }

    @FXML
    private void searchHandler(ActionEvent event) {
           String lookName = searchText.getText();
       
       
        partTableView1.setItems(filterPart(lookName));
    }

    @FXML
    private void addHandler(ActionEvent event) {
        Part part = partTableView1.getSelectionModel().getSelectedItem();
        if (part != null) {
            partTableView1.getSelectionModel().clearSelection();
            listParts.remove(part);
            tempParts.add(part);
        }
    }

    @FXML
    private void saveHandler(ActionEvent event) throws IOException {

       try {  
        String productName = ModifyproductNameText.getText();
        Double productPrice = Double.parseDouble(ModifyproductPriceText.getText());
        int inStock = Integer.parseInt(ModifyproductStockText.getText());
        int productMin = Integer.parseInt(ModifyproductMinText.getText());
        int productMax = Integer.parseInt(ModifyproductMaxText.getText());
        ObservableList<Part> associatedParts = getTempParts();         
            
           
            
            Part selectedPart = partTableView1.getSelectionModel().getSelectedItem();
            boolean addFail = false;
            
           
          double associatedPartsTotal = 0;
     
     for(int i = 0; i < tempParts.size(); i++)
     {
         associatedPartsTotal += tempParts.get(i).getPartPrice();
     }
   
                     
                     
   
            
         if (selectedPart != null) {
            draftProduct.getAssociatedParts().add(selectedPart);
            partTableView2.setItems(draftProduct.getAssociatedParts()); 
         }
         
         if (tempParts.isEmpty()){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product must have at least one part.");
            alert.showAndWait();
            addFail = true;             
         }
         
            if (productPrice < associatedPartsTotal){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product price must be greater than sum of parts.");
            alert.showAndWait();
            addFail = true;
                
            }
                    
            if (productMin >= productMax){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product Min cannot be greater than Product Max");
            alert.showAndWait();
            addFail = true;
             }
            
            if (productMax < productMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product Max cannot be less than Product Min");
            alert.showAndWait();
            addFail = true;
             }
            
            if (inStock > productMax){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot exceed Product Maximum");
            alert.showAndWait();
            addFail = true;
             }
            
              if (inStock < productMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot be less than Part Minimum");
            alert.showAndWait();
            addFail = true;
             }
            
            if (addFail == false) {
            
            Product p = new Product (associatedParts, productName, productPrice, inStock, productMin, productMax);    
                    
            
                for (int i=0; i<associatedParts.size(); i++){
                    p.addAssociatedParts(associatedParts.get(i));
                }
            Inventory.addProduct(p);
            
            
            Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);

            //This line gets the Stage information
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(tableViewScene);
            window.show();
            }

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Please enter a valid value for each text field");
            alert.showAndWait();
        }
    }

    @FXML
    private void cancelHandler(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Your actions have not been saved. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {

            Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);

            //This line gets the Stage information
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(tableViewScene);
            window.show();
        }

    }

    @FXML
    private void deleteHandler(ActionEvent event) throws IOException {

        Part part = partTableView2.getSelectionModel().getSelectedItem();
        if (part != null) {
            partTableView2.getSelectionModel().clearSelection();
            tempParts.remove(part);
            listParts.add(part);
        }
    }
    Product product1;
    void setProduct(Product product, String modify) {
        
       this.product1 = product;
     
   ModifyproductIDText.setText(Integer.toString(product.getProductID()));
   ModifyproductNameText.setText(product.getProductName());
   ModifyproductStockText.setText(Integer.toString(product.getInStock()));
   ModifyproductPriceText.setText(Double.toString(product.getProductPrice()));
   ModifyproductMinText.setText(Integer.toString(product.getProductMin()));
   ModifyproductMaxText.setText(Integer.toString(product.getProductMax()));
  
    }
   
    ObservableList<Part> associatedParts1;
    void setTableView2(ObservableList<Part> associatedPart, String modify) {
        
       this.associatedParts1 = associatedPart;
       this.tempParts.addAll(associatedPart);
   partTableView2.setItems(tempParts);
 
   partIDCollumn2.setCellValueFactory(new PropertyValueFactory<>("partID"));
   partNameCollumn2.setCellValueFactory(new PropertyValueFactory<>("partName"));
   partPriceCollumn2.setCellValueFactory(new PropertyValueFactory<>("partPrice"));
   partStockCollumn2.setCellValueFactory(new PropertyValueFactory<>("partStock"));
        

   
   
    }
    
}
