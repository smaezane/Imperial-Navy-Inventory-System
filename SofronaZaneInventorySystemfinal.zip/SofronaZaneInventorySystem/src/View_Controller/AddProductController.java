/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.Inventory;
import static Model.Inventory.getfilteredParts;
import static Model.Inventory.listParts;
import Model.Part;
import Model.Product;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.function.Predicate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Sofrona
 */
public class AddProductController implements Initializable {

    
    @FXML
    private Button searchButton;
    @FXML
    private TableColumn<Part, Integer> partIDCollumn1;
    @FXML
    private TableColumn<Part, String> partNameCollumn1;
    @FXML
    private TableColumn<Part, Integer> partStockCollumn1;
    @FXML
    private TableColumn<Part, Double> partPriceCollumn1;
    @FXML
    private TextField searchText;
    @FXML
    private Button addButton;
    @FXML
    private Button saveButton;
    @FXML
    private Button cancelButton;
    @FXML
    private TableColumn<Part, Integer> partIDCollumn2;
    @FXML
    private TableColumn<Part, String> partNameCollumn2;
    @FXML
    private TableColumn<Part, Integer> partStockCollumn2;
    @FXML
    private TableColumn<Part, Double> partPriceCollumn2;
    @FXML
    private Button deleteButton;
    @FXML
    private TextField AddproductIDText;
    @FXML
    private TextField AddproductNameText;
    @FXML
    private TextField AddproductStockText;
    @FXML
    private TextField AddproductPriceText;
    @FXML
    private TextField AddproductMinText;
    @FXML
    private TextField AddproductMaxText;
    @FXML
    public TableView<Part> partTableView1;
    @FXML
    private TableView<Part> partTableView2;
    private Product draftProduct;

    private  ObservableList<Part> tempParts = FXCollections.observableArrayList();
    public  FilteredList<Part> filteredData = new FilteredList<>(listParts, p -> true);
    private  FilteredList<Part> getfilteredData;
    public  FilteredList<Part> getfilteredData() {
        return getfilteredData;
   
    }
    
     public ObservableList<Part> getTempParts() {
        return tempParts;
    }
     

  
  
 
      public ObservableList<Part> filterPart(String searchInput) {
        if (!(Inventory.getselectedParts().isEmpty())) {
            Inventory.getselectedParts().clear();
        }
        
        if (Inventory.getselectedParts().isEmpty()){
            Inventory.getselectedParts();
        
        }
        try 
        { 
            // checking valid integer using parseInt() method 
            Integer.parseInt(searchInput); 
            for (Part part : Inventory.getlistParts()) {
            if (part.getPartID() == Integer.parseInt(searchInput)) {
                Inventory.getselectedParts().add(part);
            
        }  
            }
        }
        catch (NumberFormatException e)  
        { 
            String lowerCaseFilter = searchInput.toLowerCase();
            
            for (Part part : Inventory.getlistParts()) {
            if (part.getPartName().toLowerCase().contains(lowerCaseFilter)) {
                Inventory.getselectedParts().add(part);
        } 
            }
        }
     return Inventory.getselectedParts();
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        partTableView1.setItems(Inventory.getlistParts());
        partTableView2.setItems(Inventory.getselectedParts());

        partIDCollumn1.setCellValueFactory(new PropertyValueFactory<>("partID"));
        partNameCollumn1.setCellValueFactory(new PropertyValueFactory<>("partName"));
        partPriceCollumn1.setCellValueFactory(new PropertyValueFactory<>("partPrice"));
        partStockCollumn1.setCellValueFactory(new PropertyValueFactory<>("partStock"));

        partTableView2.setItems(tempParts);
        partIDCollumn2.setCellValueFactory(new PropertyValueFactory<>("partID"));
        partNameCollumn2.setCellValueFactory(new PropertyValueFactory<>("partName"));
        partPriceCollumn2.setCellValueFactory(new PropertyValueFactory<>("partPrice"));
        partStockCollumn2.setCellValueFactory(new PropertyValueFactory<>("partStock"));
    
     
    }

    @FXML
    public void searchHandler(ActionEvent event) {
        String lookName = searchText.getText();
       
       
        partTableView1.setItems(filterPart(lookName));
      
    }
                


    @FXML
    private void addHandler(ActionEvent event) {
        Part part = partTableView1.getSelectionModel().getSelectedItem();
        if (part != null) {
            partTableView1.getSelectionModel().clearSelection();
            tempParts.add(part);
        }
    }

    @FXML
    private void saveHandler(ActionEvent event) throws IOException {

        try {
            
            String productName = AddproductNameText.getText();
            Double productPrice = Double.parseDouble(AddproductPriceText.getText());
            int inStock = Integer.parseInt(AddproductStockText.getText());
            int productMin = Integer.parseInt(AddproductMinText.getText());
            int productMax = Integer.parseInt(AddproductMaxText.getText());
            ObservableList<Part> associatedParts = getTempParts();
            
            Part selectedPart = partTableView1.getSelectionModel().getSelectedItem();
            boolean addFail = false;
            
           
          double associatedPartsTotal = 0;
     
     for(int i = 0; i < tempParts.size(); i++)
     {
         associatedPartsTotal += tempParts.get(i).getPartPrice();
     }
   
                     
                     
   
            
         if (selectedPart != null) {
            draftProduct.getAssociatedParts().add(selectedPart);
            partTableView2.setItems(draftProduct.getAssociatedParts()); 
         }
         
         if (tempParts.isEmpty()){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product must have at least one part.");
            alert.showAndWait();
            addFail = true;             
         }
         
            if (productPrice < associatedPartsTotal){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product price must be greater than sum of parts.");
            alert.showAndWait();
            addFail = true;
                
            }
                    
            if (productMin >= productMax){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product Min cannot be greater than Product Max");
            alert.showAndWait();
            addFail = true;
             }
            
            if (productMax < productMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Product Max cannot be less than Product Min");
            alert.showAndWait();
            addFail = true;
             }
            
            if (inStock > productMax){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot exceed Product Maximum");
            alert.showAndWait();
            addFail = true;
             }
            
              if (inStock < productMin){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Inventory Level cannot be less than Part Minimum");
            alert.showAndWait();
            addFail = true;
             }
            
            if (addFail == false) {
            
            Product p = new Product (associatedParts, productName, productPrice, inStock, productMin, productMax);    
                    
            
                for (int i=0; i<associatedParts.size(); i++){
                    p.addAssociatedParts(associatedParts.get(i));
                }
            Inventory.addProduct(p);
            
            
            Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);

            //This line gets the Stage information
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(tableViewScene);
            window.show();
            }

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialogue");
            alert.setContentText("Please enter a valid value for each text field");
            alert.showAndWait();
        }
        //NullPointerException
    }


    @FXML
    private void cancelHandler(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Your actions have not been saved. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {

            Parent tableViewParent = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.show();
        }

    }

    @FXML
    private void deleteHandler(ActionEvent event) throws IOException {

        Part part = partTableView2.getSelectionModel().getSelectedItem();
        if (part != null) {
            partTableView2.getSelectionModel().clearSelection();
            tempParts.remove(part);
            
        }

    }

}
