/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sofronazaneinventorysystem;

import Model.InhousePart;
import Model.Inventory;
import static Model.Inventory.listParts;
import Model.Part;
import Model.Product;
import Model.outsourcedPart;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Sofrona
 */
public class SofronaZaneInventorySystem extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        InhousePart part1 = new InhousePart(1, "Deflector Shield", 1500, 62, 10, 100);
        outsourcedPart part2 = new outsourcedPart("Star Forge", "Ion Cannon", 2000, 38, 10, 200);
        outsourcedPart part3 = new outsourcedPart("Star Forge", "Ion Engine", 5000, 14, 10, 200);
        InhousePart part4 = new InhousePart(2, "Turbolaser Battery", 980, 78, 10, 200);
        InhousePart part5 = new InhousePart(3, "Tractor Beam", 1260, 119, 10, 200);
        outsourcedPart part6 = new outsourcedPart("Kuat DriveYards", "Hyperdrive", 6670, 8, 10, 200);
        InhousePart part7 = new InhousePart(4, "Turbolaser Turret", 1190, 79, 10, 200);

        Inventory.addPart(part1);
        Inventory.addPart(part2);
        Inventory.addPart(part3);
        Inventory.addPart(part4);
        Inventory.addPart(part5);
        Inventory.addPart(part6);
        Inventory.addPart(part7);

        Product product1 = new Product( "Executor", 830000, 5, 10, 200);
        Product product2 = new Product( "Dreadnaught", 530000, 5, 10, 200);
        Product product3 = new Product( "Venator", 570000, 5, 10, 200);
        Product product4 = new Product( "Imperial II", 630000, 5, 10, 200);
        Product product5 = new Product( "TIE Starfighter", 230000, 5, 10, 200);
        Product product6 = new Product( "Lambda", 101000, 5, 10, 200);
        Product product7 = new Product( "TIE Advanced x1", 270000, 5, 10, 200);

        Inventory.addProduct(product1);
        Inventory.addProduct(product2);
        Inventory.addProduct(product3);
        Inventory.addProduct(product4);
        Inventory.addProduct(product5);
        Inventory.addProduct(product6);
        Inventory.addProduct(product7);
        
        
        
        launch(args);
    }

}
