/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import static Model.Inventory.getlistParts;
import View_Controller.AddProductController;
import javafx.collections.ObservableList;

/**
 *
 * @author Sofrona
 */
public abstract class Part {

    public static Part searchpart(Part part) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private int partID;
    private String partName;
    private double partPrice;
    private int partStock;
    private int partMin;
    private int partMax;
    private static int numPart;

    public Part(String name, double price, int inStock, int min, int max) {
        this.partID = ++numPart;
        this.partName = name;
        this.partPrice = price;
        this.partStock = inStock;
        this.partMin = min;
        this.partMax = max;
    }

    /**
     * @return the partID
     */
    public int getPartID() {
        return partID;
    }

    /**
     * @param partID the partID to set
     */
    public void setPartID(int partID) {
        this.partID = partID;
    }

    /**
     * @return the partName
     */
    public String getPartName() {
        return partName;
    }

    /**
     * @param partName the partName to set
     */
    public void setPartName(String partName) {
        this.partName = partName;
    }

    /**
     * @return the partPrice
     */
    public double getPartPrice() {
        return partPrice;
    }
    

    /**
     * @param partPrice the partPrice to set
     */
    public void setPartPrice(double partPrice) {
        this.partPrice = partPrice;
    }

    /**
     * @return the partStock
     */
    public int getPartStock() {
        return partStock;
    }

    /**
     * @param partStock the partStock to set
     */
    public void setPartStock(int partStock) {
        this.partStock = partStock;
    }

    /**
     * @return the partMin
     */
    public int getPartMin() {
        return partMin;
    }

    /**
     * @param partMin the partMin to set
     */
    public void setPartMin(int partMin) {
        this.partMin = partMin;
    }

    /**
     * @return the partMax
     */
    public int getPartMax() {
        return partMax;
    }

    /**
     * @param partMax the partMax to set
     */
    public void setPartMax(int partMax) {
        this.partMax = partMax;
    }
 
    /**
     * @return the numPart
     */
    
    
    public static int getNumPart() {
        return numPart;
    }
   /* public static Part searchforpart(String lookName){
        
       // AddProductController.partIDCollumn1.setCellValueFactory(cellData -> cellData.getValue().getPartID());
       // AddProductController.partNameCollumn1.setCellValueFactory(cellData -> cellData.getValue().getPartName());
               
        if (lookName == null || lookName.isEmpty()) {
                  return null;
        }
                
                
        for (Part part : Inventory.listParts) {
            if (part.getPartName().contains(lookName) || Integer.toString(part.getPartID()).equals(lookName)){
                return part;
            } 
        }
           
         return null;     
        }  */
    }
    

