/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Sofrona
 */
public class Product {

    /**
     *
     */
    public ObservableList<Part> associatedParts = FXCollections.observableArrayList();

    private int productID;
    private String productName;
    private double productPrice;
    private int inStock;
    private int productMin;
    private int productMax;
    private static int numProduct;

   public Product(String name, double price, int inStock, int min, int max) {
        this.productID = ++numProduct;
        this.productName = name;
        this.productPrice = price;
        this.inStock = inStock;
        this.productMin = min;
        this.productMax = max;
   }
        
   public Product(ObservableList<Part> associatedParts, String name, double price, int inStock, int min, int max) {
        
       this.productID = ++numProduct;
        this.productName = name;
        this.productPrice = price;
        this.inStock = inStock;
        this.productMin = min;
        this.productMax = max;
        
       
   }
   
 

    public ObservableList<Part> getAssociatedParts() {
        return associatedParts;
    }

    
    
    public void setAssociatedParts(ObservableList<Part> associatedParts) {
        this.associatedParts = associatedParts;
    }

   public void addAssociatedParts(Part part) {
        associatedParts.add(part);
        }
   

   
     
    public int getProductID() {
        return productID;
    }

    /**
     * @param productID the productID to set
     */
    public void setProductID(int productID) {
        this.productID = productID;
    }

    /**
     * @return the productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName the productName to set
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * @return the productPrice
     */
    public double getProductPrice() {
        return productPrice;
    }

    /**
     * @param productPrice the productPrice to set
     */
    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    /**
     * @return the inStock
     */
    public int getInStock() {
        return inStock;
    }

    /**
     * @param inStock the inStock to set
     */
    public void setInStock(int inStock) {
        this.inStock = inStock;
    }

    /**
     * @return the productMin
     */
    public int getProductMin() {
        return productMin;
    }

    /**
     * @param productMin the productMin to set
     */
    public void setProductMin(int productMin) {
        this.productMin = productMin;
    }

    /**
     * @return the productMax
     */
    public int getProductMax() {
        return productMax;
    }

    /**
     * @param productMax the productMax to set
     */
    public void setProductMax(int productMax) {
        this.productMax = productMax;
    }

    public void setProduct(Product product) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
   
        
    
}
