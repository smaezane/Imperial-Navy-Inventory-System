/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Sofrona
 */
public class Inventory {

    public static ObservableList<Product> listProducts = FXCollections.observableArrayList();
    public static ObservableList<Product> filteredProducts = FXCollections.observableArrayList();
    public static ObservableList<Product> selectedProducts = FXCollections.observableArrayList();
    public static ObservableList<Part> listParts = FXCollections.observableArrayList();
    public static ObservableList<Part> selectedParts = FXCollections.observableArrayList();
    public static ObservableList<Part> filteredParts = FXCollections.observableArrayList();

    public static ObservableList<Product> getlistProducts() {
        return listProducts;
    }
    
     public static ObservableList<Product> getselectedProducts() {
        return selectedProducts;
    }
    public static ObservableList<Product> getfilteredProducts() {
        return filteredProducts;
    }

    public static ObservableList<Part> getlistParts() {
        return listParts;
    }

    public static ObservableList<Part> getselectedParts() {
        return selectedParts;
    }
    public static ObservableList<Part> getfilteredParts() {
        return filteredParts;
    }
    
    
    public static void addProduct(Product product) {
        listProducts.add(product);
    }

    public boolean removeProduct() {
        return false;

    }

    public Product lookupProduct() {
        return null;
    }

    public void updateProduct() {

    }

    public static void addPart(Part part) {
        listParts.add(part);
    }

    public static Part lookupPart(int PartID){
        
        return null;
    }
    public static Product lookupProduct(int ProductID){
        return null;
    }
    
    public static ObservableList<Part> lookupPart(String PartName){
        return null;
    }
    public static ObservableList<Product> lookupProduct(String ProductName){
        return null;
    }
    
       
    
}
       
    
     
